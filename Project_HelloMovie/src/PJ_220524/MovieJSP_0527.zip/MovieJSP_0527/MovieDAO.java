package kr.co.ezen.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Vector;

import javax.naming.Context;
import javax.naming.InitialContext;

import org.apache.tomcat.jdbc.pool.DataSource;

import kr.co.ezen.VO.MovieVO;

	public class MovieDAO {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs = null;
	
		public void getConnection() {
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String Driver = "oracle.jdbc.driver.OracleDriver";
			String id = "C##HELLO";
			String pwd = "MOVIE";
			try	{
				Class.forName(Driver);
				conn = DriverManager.getConnection(url, id, pwd);
			} catch(Exception e) {
				e.printStackTrace();
			}
		}// close getConnection()
		private static MovieDAO instance = new MovieDAO();
	
		public static MovieDAO getInstance(){
			return instance;   
		}
		private MovieDAO() {} //생성자
		 // DB연결
//		public Connection getConnection() {
//			try {			
//				Context initctx = new  InitialContext();
//				DataSource ds = (DataSource) initctx.lookup("java:comp/env/jdbc/OracleDB");			
//				conn = ds.getConnection();
//				
//			}catch(Exception e) {
//				e.printStackTrace();
//			}
//			return conn;		
//		}
		 // 1.영화등록 
		public void insertMovie(MovieVO mvvo) {
			getConnection();
			try {
				String sql = "INSERT INTO MOVIE "
						+ "(MOVIE_IMG, MOVIE_CODE,MOVIE_TITLE,DIRECTOR,D_DAY,GENRE,MOVIE_AGE,"
						+ "ACTOR,MOVIE_PRICE,MOVIE_SOLD,SUMMARY)"
						+ "VALUES(?,?,?,?,?,?,?,?,?,?,?,?)"; 
					pstmt = conn.prepareStatement(sql);
					pstmt.setString(1,mvvo.getMovie_img());
					pstmt.setString(2,mvvo.getMovie_code());
					pstmt.setString(3,mvvo.getMovie_title());
					pstmt.setString(4,mvvo.getDirector());
					pstmt.setString(5,mvvo.getD_day());
					pstmt.setString(6,mvvo.getGenre());
					pstmt.setInt(7,mvvo.getMovie_age());
					pstmt.setString(8,mvvo.getActor());
					pstmt.setInt(9,mvvo.getMovie_price());
					pstmt.setInt(10,mvvo.getMovie_sold());	
					pstmt.setString(11,mvvo.getSummary());
					pstmt.executeUpdate();

				conn.close();
				pstmt.close();
				System.out.println("관리자 영화 등록 성공");
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("관리자 영화 등록 실패");
			}
		} // close insertMovie()
		
		 // 2. 영화수정(1개) 
		public void updateMovie(MovieVO mvvo){
			
			getConnection();
			try {
				String sql = "UPDATE SET MOVIE "
						+ "(MOVIE_IMG=?,MOVIE_CODE=MOVEI_CODE,MOVIE_TITLE=?,DIRECTOR=?,D_DAY=?,"
						+ "GENRE=?,MOVIE_AGE=?,ACTOR=?,MOVIE_PRICE,MOVIE_SOLD=?,SUMMARY=?)"
						+ "WHERE MOVIE_CODE=?";
					pstmt = conn.prepareStatement(sql);
					pstmt.setString(1,mvvo.getMovie_img());
					pstmt.setString(2,mvvo.getMovie_code());
					pstmt.setString(3,mvvo.getMovie_title());
					pstmt.setString(4,mvvo.getDirector());
					pstmt.setString(5,mvvo.getD_day());
					pstmt.setString(6,mvvo.getGenre());
					pstmt.setInt(7,mvvo.getMovie_age());
					pstmt.setString(8,mvvo.getActor());
					pstmt.setInt(9,mvvo.getMovie_price());
					pstmt.setInt(10,mvvo.getMovie_sold());	
					pstmt.setString(11,mvvo.getSummary());
					pstmt.executeUpdate();
				conn.close();
				pstmt.close();
				System.out.println("관리자 영화 수정 성공");
			}catch(Exception e) {
				e.printStackTrace();
				System.out.println("관리자 영화 수정 실패");
			}
		} //close updateMovie()
		
		 // 3. 영화 전체(리스트) : 관리자  조회 -- Vector
		public Vector<MovieVO> selectAllMovieList(){
			Vector<MovieVO> vo = new Vector<MovieVO>();
			MovieVO mvvo = null;
			getConnection();
			try {
				String Sql = "SELECT MOVIE_IMG,MOVIE_CODE,MOVIE_TITLE,DIRECTOR,D_DAY,"
						+ "GENRE,MOVIE_AGE,ACTOR,MOVIE_PRICE,MOVIE_SOLD,SUMMARY FROM MOVIE ORDER BY MOVIE_CODE";
				pstmt = conn.prepareStatement(Sql);
				rs = pstmt.executeQuery();
				
				while(rs.next()) {
					mvvo = new MovieVO();
					mvvo.setMovie_img(rs.getString(1));
					mvvo.setMovie_code(rs.getString(2));
					mvvo.setMovie_title(rs.getString(3));
					mvvo.setDirector(rs.getString(4));
					mvvo.setD_day(rs.getString(5));
					mvvo.setGenre(rs.getString(6));
					mvvo.setMovie_age(rs.getInt(7)); 
					mvvo.setActor(rs.getString(8));
					mvvo.setMovie_price(rs.getInt(9));
					mvvo.setMovie_sold(rs.getInt(10));
					mvvo.setSummary(rs.getString(11));
					vo.add(mvvo);
					System.out.println("관리자 영화 전체 조회 성공");
				}
				conn.close();
				pstmt.close();
				rs.close();
			}catch(Exception e) {
				e.printStackTrace();
				
				System.out.println("관리자 영화 전체 조회 실패");
			} 
			return vo;
		}// close selectAllMovieList()
		
		// 4. 영화 상세 조회 - 관리자, 회원? (이미지클릭은? 어쩔?
		public MovieVO selectMovieDetail (String movie_code) {
			MovieVO mvvo1 = new MovieVO();  
			//ResultSet rs = null;
			//int result=0; , void int()로 //반환시
			getConnection();
			try {
				String sql = "SELECT MOVIE_IMG,MOVIE_CODE,MOVIE_TITLE,DIRECTOR,"
						+ "D_DAY,GENRE,MOVIE_AGE,ACTOR,MOVIE_PRICE,MOVIE_SOLD,SUMMARY FROM MOVIE ORDER BY D_DAY DESC"; //개봉일순
						
				pstmt = conn.prepareStatement(sql);
				rs = pstmt.executeQuery();
//				1. MOVIE_IMG
//				2. MOVIE_CODE
//				3. MOVIE_TITLE
//				4. DIRECTOR
//				5. D_DAY
//				6. GENRE
//				7. MOVIE_AGE
//				8. ACTOR
//				9. MOVIE_PRICE
//				10. MOVIE_SOLD
//				11. SUMMARY 
				if(rs.next()) {
					mvvo1.setMovie_img(rs.getString(1));
					mvvo1.setMovie_code(rs.getString(2));
					mvvo1.setMovie_title(rs.getString(3));
					mvvo1.setDirector(rs.getString(4));
					mvvo1.setD_day(rs.getString(5));
					mvvo1.setGenre(rs.getString(6));
					mvvo1.setMovie_age(rs.getInt(7));
					mvvo1.setActor(rs.getString(8));
					mvvo1.setMovie_price(rs.getInt(9));
					mvvo1.setMovie_sold(rs.getInt(10));
					mvvo1.setSummary(rs.getString(11));
				}
				conn.close();
				pstmt.close();
				rs.close();
				System.out.println("관리자 영화 상세 조회 성공");
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("관리자 영화 상세 조회 실패");
			}
			return mvvo1;
		} // close selectMovieDetail()
		
		// 5. 영화 삭제 deleteMovie
		public void deleteMovie(String movie_code) {
			getConnection();
			try {
				String sql = "DELETE FROM MOVIE WHERE MOVIE_CODE=?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1,movie_code);
				pstmt.executeUpdate();
				conn.close();
				pstmt.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}// close deleteMovie()
		
		// .영화 조회 
		// .영화 목록 조회
		// 7. 최신 영화 조회 
		public Vector<MovieVO> selectMainPoster(){
			Vector<MovieVO> v = new Vector<MovieVO>();
			getConnection();
			try {
				String sql = "SELECT * FROM MOVIE ORDER BY D_DAY DESC";
				pstmt = conn.prepareStatement(sql);
				rs = pstmt.executeQuery();
				int count = 0;
				while(rs.next()) {
					MovieVO mvvo = new MovieVO();
					mvvo.setCategory(rs.getString(1));
					v.add(mvvo);
					count++;
					if(count>=3)break;
				}
				conn.close();
				pstmt.close();
				rs.close();
				System.out.println("회원 최신 영화 조회 실패");
			}catch(Exception e) {
				e.printStackTrace();
				System.out.println("회원 최신 영화 조회 실패");
			}
			return v;
		} //close selectMainPoster()

		// 6. 인기 영화 조회 selectPopularityMovie 
		public Vector<MovieVO> selectPopularityMovie(){
			Vector<MovieVO> v = new Vector<MovieVO>();
			getConnection();
			try {
				String sql = "SELECT MOVIE_CODE,SUM(MOVIE_PRICE) FROM MOVIE GROUP BY MOVIE_CODE ORDER BY SUM(MOVIE_PRICE*MOVIE_SOLD) DESC";
				pstmt = conn.prepareStatement(sql);
				rs = pstmt.executeQuery();
				int sum = 0;
				while(rs.next()) {
					MovieVO mvvo = new MovieVO();
					mvvo.setMovie_img(rs.getString(1));
					v.add(mvvo);
					
				}
				conn.close();
				pstmt.close();
				rs.close();
				System.out.println("회원 인기 영화 조회 성공");
			}catch(Exception e) {
				e.printStackTrace();
				System.out.println("회원 인기 영화 조회 실패");
			}
			return v;
		} //close 인기 영화 조회 
	
		// 8. 장르별 조회 selectGenreMovie
		public Vector<MovieVO> selectGenreMovie(){
			Vector<MovieVO> v = new Vector<MovieVO>();
			MovieVO mvvo = null;
			getConnection();
			try {
				String Sql = "SELECT * FROM MOVIE WHERE GENRE=?";
				pstmt = conn.prepareStatement(Sql);
				rs = pstmt.executeQuery();
				
				while(rs.next()) {
					mvvo = new MovieVO();
					mvvo.setCategory(rs.getString(1));
					v.add(mvvo);
					System.out.println("회원 장르 영화 조회 성공");
				}
				conn.close();
				pstmt.close();
				rs.close();
				System.out.println("회원 장르 영화 조회 실패");
			}catch(Exception e) {
				e.printStackTrace();
			}
			return v;
		} //close selectGenreMovie()
		
		// 9. 연령별 조회 selectAgeMovie (19세이하)
		public Vector<MovieVO> selectAgeMovie(){
			Vector<MovieVO> v = new Vector<MovieVO>();
			MovieVO mvvo = null;
			getConnection();
			try {
				String Sql = "SELECT * FROM MOVIE WHERE AGE>=19";
				pstmt = conn.prepareStatement(Sql);
				rs = pstmt.executeQuery();
				
				while(rs.next()) {
					mvvo = new MovieVO();
					mvvo.setCategory(rs.getString(1));
					v.add(mvvo);
					System.out.println("회원 연령 영화 조회 성공");
				}
				conn.close();
				pstmt.close();
				rs.close();
			}catch(Exception e) {
				e.printStackTrace();
				System.out.println("회원 연령 영화 조회 실패");
			}
			return v;
		} //close selectAgeMovie()
		
		// 10. 영화검색 searchMovie
		
		// 관리자 인증 (맴버쉽 : 0: 매니저(관리자) , 1: 패밀리(회원))  
//		public managerCheck(String MOVIE_CODE)throws Exception {
//			getConnection();
//			String db_pwd ="";
//			try {
//				String sql = "SELECT PWD FROM MEMBER WHERE MOVIE_CODE=?"; // 입력값 받고 영화코드 수정/삭제
//				pstmt = conn.prepareStatement(sql);
//				pstmt.setString(1, MOVIE_ID);
//				rs = pstmt.executeQuery();
//				if(rs.next()) {
//					db_pwd = rs.getString(1);
//					}
//				conn.close();
//				pstmt.close();
//				rs.close();
//			}catch(Exception e) {
//				e.printStackTrace();
//			}
//		return;
//		} //close managerCheck()
 
	}// close MovieDAO()
